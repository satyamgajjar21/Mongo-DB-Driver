//Mongo db driver
const MongoClient = require('mongodb').MongoClient;
const assert = require('assert');

// Connection URL
const url = 'mongodb://localhost:27017';

// Database Name
const dbName = 'fruitsDB';

// Create a new MongoClient
const client = new MongoClient(url);

// Use connect method to connect to the Server
client.connect(function(err) {
  assert.equal(null, err);
  console.log("Connected successfully to server");

  const db = client.db(dbName);

  //call: to insert 
//   insertDocuments(db, function(){
//     client.close();
//   });

//call: to find 
    findDocuments(db, function() {
      client.close();
    });
  
});


//insert 
const insertDocuments = function(db, callback) {
    // Get the documents collection
    const collection = db.collection('documents');
    // Insert some documents
    collection.insertMany([
      {
        name: "Apple",
        score: 8,
        review: "Great fruit"
      },
      {
        name: "Orange",
        score: 6,
        review: "Sour"
      },
      {
        name: "Banana",
        score: 9,
        review: "Great fruit!"
      },
    ], function(err, result) { 
      console.log("Inserted 3 documents into the collection");
      callback(result);
    });
  }

//find
const findDocuments = function(db, callback) {
    // Get the documents collection
    const collection = db.collection('fruits');
    // Find some documents
    collection.find({}).toArray(function(err, fruits) {
      assert.equal(err, null);
      console.log("Found the following records");
      console.log(fruits)
      callback(fruits);
    });
  }




































// const mongoose = require('mongoose');

// mongoose.connect("mongodb://localhost:27017/fruitsDB", {useNewUrlParser: true});

// const fruitSchema = new mongoose.Schema({
// name: String,
// rating: Number,
// review: String
// })

// const Fruit = mongoose.model("Fruit", fruitSchema);

// const fruit = new Fruit({
//     name: "Apple",
//     rating: 7,
//     review: "Good"
// });

// fruit.save();
 
// const findDocuments = function(db,callback){
//     //get the doc collectiuon
//     const collection = db.collection('fruits');

//     //find some documents
//     collection.find({}).toArray(function(err, fruits){
//         AuthenticatorAssertionResponse.equal(err,null);
//         console.log("Found the following records");
//         console.log(fruits);
//         callback(fruits);

//     });
// };